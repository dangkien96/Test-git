<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Mail\Warning;
use App\Model\Product;
use App\Model\ProductBill;
use App\Models\Bill;
use App\User;
use Illuminate\Http\Request;
use Cart,Session,Auth,DB;
use Illuminate\Support\Facades\Mail;

class CartController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }
    public function cart(){
        $data=Cart::content();
        return view('backend.cart.cart',compact('data'));
    }
    // thêm sản phẩm vào giỏ hàng
    public function create (Request $request)
    {
        $id = $request->product_id;
//       dd($id);
        $product_info = Product::find($id);
//               dd($product_info);
        if (empty($product_info)) {
            return back()->with('error', 'Sản phẩm không tồn tại');
        }
        if ($product_info['price_discount'] > 0) {

            $price = $product_info['price_discount'];
        } else {

            $price = $product_info['price'];
        }
        $option = [
            'avatar' => $product_info['avatar'],
            'price' => $product_info['price'],
            'price_discount' => $product_info['price_discount'],
            'total' => $product_info['total'],
            'avali' => $product_info['total']-$product_info['sold']
        ];
//        dd($option);

        $cart = Cart::add($product_info['id'], $product_info['name'], 1, $price, $option);
        if ($cart) {
            $data = Cart::content();
//            dd($data);
            Session::put('total', $data);
            return back()->with('success', 'Thêm vào giỏ thành công');
        } else {
            return back()->with('error', 'Thêm vào giỏ thất bại');
        }

    }


    // cập nhật số lượng sản phẩm trong giỏ hàng
    public function update($id, $total)
    {
//        dd($id,$total);
        Cart::update($id, $total);
        $data = Cart::content();
//        dd($data);
        Session::put('total', $data);
        return back()->with('success', 'Cập nhật giỏ thành công');
    }


    // xóa 1 sản phẩm trong giỏ hàng
    public function delete($id)
    {
        Cart::remove($id);
        $data = Cart::content();
        Session::put('total', $data);
        return back()->with('success', 'Xóa khỏi giỏ thành công');
    }


    // xóa tất cả sản phẩm trong giỏ hàng
    public function destroy()
    {
        Cart::destroy();
    }


    // tạo đơn hàng
    public function createBill(Request $request)
    {
        $bill = json_decode($request->bill);
        $total = $request->total;
        $price = $request->price;
        $product_list_email=[];
        if (Auth::user()) {
            $user_buy = Auth::user()->name;
            $user_info = Auth::user()->id;
            $user_email=Auth::user()->email;
        } else {
            $email=$request->email;
            $phone=$request->phone;
            $name=$request->name.'_khách lẻ';
            $address=$request->address;
            if ($this->validateEmail($email)==false){
                return back()->with('error','Tài khoản email không hợp lệ');
            }
            if (strlen($phone)<10 and strlen($phone)>11){
                return back()->with('error','Số điện thoại nằm trong khoảng 10->11 số ');

            }
            $checkUser=User::where([
                'email'=>$email,
                'phone'=>$phone
            ])->select('email','phone','id','name')->first();
            if ($checkUser==null){
                $user=User::create([
                    'email'=>$email,
                    'phone'=>$phone,
                    'name'=>$name,
                    'address'=>$address
                ]);
                if ($user){
                    $user_buy=$name;
                    $user_info=$user->id;
                    $user_email=$user->email;
                }
            }else{
                $user_buy=$checkUser['name'];
                $user_email=$checkUser['email'];
                $user_info=$checkUser['id'];
            }
        }
        $i = 0;
        foreach ($bill as $item) {
            $i++;
            $list_product[$item->total] = $item->id;

        }
//        dd($list_product);
        DB::beginTransaction();

        try {
            //tạo bill lưu db
            $name = $user_buy . '-' . date('d/m/Y H:i:s');
            $bill_create = new Bill;
            $bill_create->name = $name;
            $bill_create->total = $total;
            $bill_create->price = $price;
            $bill_create->product_list = json_encode($list_product);
            $bill_create->user_info = $user_info;
            $bill_create->status = 0;
//            dd($bill_create);
            $bill_create->save();
            foreach ($bill as $item) {

                $product = Product::find($item->id);
                $old_sold=$product['sold'];
                $product['total_buy']=$item->total;

                $product_list_email[]=$product;
                if ($product['price_discount']<=0){
                    $price=$product['price'];
                }else{
                    $price=$product['price_discount'];
                }
                //nếu có thông tin sp => lưu id bill + mã sp vào bảng ProductBill
                if ($product) {
                    $end = $product['total'] - $item->total;
                    if ($end >= 0) {
                        //giảm số lượng sp
                        Product::where('id',$item->id)->update([
                            'sold'=>$item->total+$old_sold,

                        ]);
                        ProductBill::create([
                            'total'=>$item->total,
                            'product_id'=>$item->id,
                            'bill_id'=>$bill_create->id,
                            'value'=>$item->total*$price
                        ]);

                    }
                }
            }
            $warning['name']=$user_buy;
            $warning['sender']='Siêu Thị 24H';
            $warning['product_list']=$product_list_email;
            $warning['total']=$total;
            $warning['price']=$request->price;
            Mail::to($user_email)->send(new Warning($warning));
            // lưu đơn hàng xong thì xóa hết sản phẩm
            $this->destroy();
            Session::put('total', '0');
            DB::commit();
            return back()->with('success', 'Tạo đơn hàng thành công');
            // all good
        } catch (\Exception $e) {
            return back()->with('error', 'Tạo đơn hàng thất bại');
            DB::rollback();
        }
    }

}
