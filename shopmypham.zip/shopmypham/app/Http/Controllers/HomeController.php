<?php

namespace App\Http\Controllers;

use App\Model\Category;
use App\Model\Product;
use App\Models\Post;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $new=Product::orderBy('id', 'desc')->take(3)->get()->toArray();
        //giảm giá
        $discount=Product::orderBy('id', 'desc')->where('price_discount','>',0)->take(4)->get()->toArray();
        //bán chạy
        $best_sell=Product::where('sold','>','0')->orderBy('sold','desc')->take(8)->get()->toArray();

        return view('backend.home.index',compact('new','discount','best_sell'));
    }
    public function search(Request $request){
//        dd($request->all());
        $key_word=$request->key_word;
        $cat_id=$request->cat_id;
        if (strlen($key_word)==0){
            return back();
        }else{
            if ($cat_id ==null){
                $product_list=Product::orderBy('id', 'desc')->where('price_discount','>',0)->where('product.name','like','%'.$key_word.'%')->select('*','id as product_id')->paginate(6);
            }else{
                $product_list=Product::join('product_category','product_category.product_id','product.id')
                    ->orderBy('product.id', 'desc')
                    ->where('product.price_discount','>',0)
                    ->where('name','like','%'.$key_word.'%')
                    ->where('category_id',$cat_id)
                    ->select('product.*','product.id as product_id')
                    ->paginate(6);
            }
            $name='Từ khóa là ( '.$key_word.' )';
            return view('backend.home.search',compact('product_list','name'));
        }
    }
    public function discount(){
        $product_list=Product::orderBy('id', 'desc')->where('price_discount','>',0)->select('*','id as product_id')->paginate(6);
//        dd($product_list);
        $name='Khuyến Mãi';
        return view('backend.home.search',compact('product_list','name'));
    }
    public function vodka(){
        $product_list=Product::join('product_category','product_category.product_id','product.id')
                            ->orderBy('product.id', 'desc')
//                            ->where('product.price_discount','<=',0)
                            ->where('category_id',15)
                            ->paginate(6);
        $name='ORGANIQUE';
        return view('backend.home.search',compact('product_list','name'));
    }
    public function hennessy(){
        $product_list=Product::join('product_category','product_category.product_id','product.id')
            ->orderBy('product.id', 'desc')
//            ->where('product.price_discount','<=',0)
            ->where('category_id',16)
            ->paginate(6);
//        dd($product_list);
        $name='BEAUTY TOOL';
        return view('backend.home.search',compact('product_list','name'));
    }
    public function chivas(){
        $product_list=Product::join('product_category','product_category.product_id','product.id')
            ->orderBy('product.id', 'desc')
//            ->where('product.price_discount','<=',0)
            ->where('category_id',13)
            ->paginate(6);
        $name='BEAUTY LIFE';
        return view('backend.home.search',compact('product_list','name'));
    }
    public function knowledge(){
        $product_list=Post::join('users','users.id','post.user_id')
            ->select('post.*','users.name as user_create')
            ->paginate(6);
        return view('backend.home.post',compact('product_list'));
    }
    public function view($id){
        $product=Product::find($id);
        $category_list=Category::join('product_category','product_category.category_id','category.id')
            ->where('product_category.product_id',$id)
            ->select('category.name','category.id')
            ->get()
            ->toArray();
        return view('backend.home.view',compact('product','category_list'));
    }
    public function productByCategory($id=false){
        $product_list=Product::join('product_category','product_category.product_id','product.id')
            ->orderBy('product.id', 'desc')
            ->where('category_id','>',$id)
            ->paginate(6);
        return view('backend.home.search',compact('product_list'));
    }
    public function productByTag($id=false){
        $product_list=Product::join('product_tag','product_tag.tag_id','product.id')
            ->orderBy('product.id', 'desc')
            ->where('tag_id','>',$id)
            ->paginate(6);
        return view('backend.home.search',compact('product_list'));
    }
    public function postView($id){
        $data=Post::join('users','users.id','post.user_id')->select('post.*','users.name as user_create')->find($id);
        $post_list=Post::join('users','users.id','post.user_id')
           ->select('post.*','users.name as user_create')
           ->orderBy('id','desc')
           ->take(5)
           ->get()
            ->toArray();
        return view('backend.posts.view',compact('data','post_list'));
    }
}
