<?php

namespace App\Http\Controllers\frontend;
use App\Http\Controllers\Controller;
use App\Http\Requests\UsersCreateRequest;
use App\Http\Requests\UsersUpdateRequest;
use Illuminate\Http\Request;
use App\User;
use DB;
use Auth;
class AdminUsersController extends Controller
{
    // danh sách sản phẩm 
    public function index()
    {
        $users=User::all();
        return view('frontend.users.index',compact('users'));

    }
    // Giao diện tạo mới sản phẩm
    public function create()
    {
        return view('frontend.users.create');
    }
    // Thêm mới sản phẩm vào database
    public function insert(UsersCreateRequest $request ){
        $name= ucwords($request->name);
        $email=$request->email;
        $pass=$request->password;
        $phone=$request->phone;
        $address=$request->address;
        $role_id=$request->role_id;
        User::create([
            'name'=>$name,
            'email'=>$email,
            'address'=>$address,
            'phone'=>$phone,
            'password' => bcrypt($pass),
            'role_id'=>$role_id
        ]);
        session()->flash('success','Tạo thành công !');
        return redirect()->route('users.index');
    }

    // Giao diện chi tiết sản phẩm
    public function view($id){
        $users= User::find($id);
        return view('frontend.users.view',compact('users'));
    }
    // Giao diện cập nhật sản phẩm
    public function edit($id)
    {
        $users= User::find($id);
        return view('frontend.users.edit',compact('users'));
    }
    // Cập nhật một sản phâm vào database
    public function update(UsersUpdateRequest $request,$id){
        $users=User::find($id);
        $users->name=$request->name;
        $users->email=$request->email;
        $users->phone=$request->phone;
        $users->address=$request->address;
        $users->role_id=$request->role_id;
        if ($users->save()){
            session()->flash('success','Cập nhật thành công !');
            return redirect()->route('users.index');
        }else{
            session()->flash('error','Cập nhật thất bại !');
            return back();
        }

    }

    // Xóa một sản phẩm
    public function delete($id)
    {
        $users=User::find($id);
        $users->delete();
        session()->flash('success','Xóa thành công !');
        return redirect()->route('users.index');
    }

}
