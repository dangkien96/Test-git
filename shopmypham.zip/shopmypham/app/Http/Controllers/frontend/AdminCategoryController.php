<?php

namespace App\Http\Controllers\frontend;
use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use App\Model\Category;
use DB;
use Auth;
class AdminCategoryController extends Controller
{

    // Hiện thị danh sách danh mục
    public function index()
    {
        $category=Category::all();
        return view('frontend.category.index',compact('category'));

    }
    // View tạo mới danh mục
    public function create()
    {
        return view('frontend.category.create');
    }

    // Thêm danh mục vào database
    public function insert(CategoryRequest $request ){
        $input=$request->all();
        Category::create($input);
        session()->flash('success','Tạo thành công !');
        return redirect()->route('category.index');
    }
    // CHi tiết 1 danh mục
    public function view($id){
        $category= Category::find($id);
        return view('frontend.category.view',compact('category'));
    }
    // Sửa một danh mục
    public function edit($id)
    {
        $category= Category::find($id);
        return view('frontend.category.edit',compact('category'));
    }
    // Cập nhật một danh muc
    public function update(CategoryRequest $request,$id){
        $category=Category::find($id);
        $category->name=$request->name;
        $category->type=$request->type;
        $category->save();
        if ($category){
            session()->flash('success','cập nhật thành công !');
            return redirect()->route('category.index');
        }else{
            session()->flash('error','cập nhật thất bại !');
            return back();
        }

    }

    // Xóa 1 danh mục
    public function delete($id)
    {
        $category=Category::find($id);
        $category->delete();
        session()->flash('success','Xóa thành công !');
        return redirect()->route('category.index');
    }

}
