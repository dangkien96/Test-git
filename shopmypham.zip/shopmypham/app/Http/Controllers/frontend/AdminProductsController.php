<?php

namespace App\Http\Controllers\frontend;
use App\Http\Controllers\Controller;
use App\Http\Requests\ProductCreateRequest;
use App\Model\Category;
use App\Model\ProductCategory;
use App\Model\Product;
use DB;
use Auth;
use Illuminate\Http\Request;

class AdminProductsController extends Controller
{
    // Danh sách sản phẩm
    public function index()
    {
        $data=Product::all();
        return view('frontend.products.index',compact('data'));
    }
    // Giao diện Tọa mới sản phẩm 
    public function create()
    {
        $category_db=Category::select('id','name')->where('type',0)->get()->toArray();
        foreach ($category_db as $key=>$item){
            $category[$item['id']]=$item['name'];
        }
//        return $category;
        return view('frontend.products.create',compact('category'));
    }

    // Tạo mới sản phẩm trong database
    public function insert(ProductCreateRequest $request ){
        $category=$request->category;
        if ($category!=''){
            $category_list=explode(',',$category);
        }else{
            session()->flash('error','Chưa chọn chuyên mục !');
            return back();
        }
        $name= ucwords($request->name);
        $avatar=$request->avatar;
        $price=$request->price;
        $price_discount=$request->price_discount;
        $total=$request->total;
        $content=$request->contents;
        if ($price<=0){
            return back()->with('error','Giá của sản phẩm phải lớn hoặc bằng 0');
        }
        if ($price_discount<=0){
            return back()->with('error','Giá khuến mại phải lớn hoặc bằng 0');
        }
        if ($price_discount>$price){
            return back()->with('error','Giá khuến mại không được lớn hơn giá của sản phẩm');
        }
        $product=Product::create([
            'name'=>$name,
            'avatar'=>$avatar,
            'total'=>$total,
            'price'=>$price,
            'price_discount' => $price_discount,
            'contents'=>$content
        ]);
        if ($product){
            ProductCategory::create([
                'category_id'=>$category,
                'product_id'=>$product->id
            ]);
        }
        session()->flash('success','Tạo thành công !');
        return redirect()->route('products.index');
    }

    // Giao diện chi tiết một sản phẩm
    public function view($id){
        $data= Product::find($id);
        $category_db=ProductCategory::join('category','category.id','product_category.category_id')->where('product_category.product_id',$id)->get(['name'])->toArray();
        foreach ($category_db as $key=>$item){
            $category[$key]=$item['name'];
        }
        $category_list='';
        if (!empty($category)){
            $category_list=implode(',',$category);
        }
        return view('frontend.products.view',compact('data','category_list'));
    }

    // Giao diện sửa sản phẩm
    public function edit($id)
    {
        //category
        //lấy toàn bộ category trong db ra
        $category_list_db=Category::select('id','name')->where('type',0)->get()->toArray();
        foreach ($category_list_db as $key=>$item){
            $category[$item['id']]=$item['name'];
        }
        //lấy ra category đã gán

        $category_used_list=ProductCategory::join('category','category.id','product_category.category_id')->where('product_category.product_id',$id)->first()->toArray();

        //dữ liệu sản phẩm
        $data= Product::find($id);
        return view('frontend.products.edit',compact('data','category','category_used_list'));
    }
    public function update(Request $request,$id){
        if (strlen($request->name)==0){
            session()->flash('error','Tên sản phẩm không được để trống !');
            return back();
        }
        $category=$request->category;
        if ($category!=''){
            $category_list=explode(',',$category);
        }else{
            session()->flash('error','Chưa chọn chuyên mục !');
            return back();
        }
        if ($request->price<=0){
            return back()->with('error','Giá của sản phẩm phải lớn hoặc bằng 0');
        }
        if ($request->price_discount<=0){
            return back()->with('error','Giá khuến mại phải lớn hoặc bằng 0');
        }
        if ($request->price_discount > $request->price){
            return back()->with('error','Giá khuến mại không được lớn hơn giá của sản phẩm');
        }
        $data=Product::find($id);
        $data->name=$request->name;
        $data->price=$request->price;
        $data->price_discount=$request->price_discount;
        $data->total=$request->total;
        $data->contents=$request->contents;
        $data->avatar=$request->avatar;

//        dd($data);
        if ($data->save()){
            $category_delete=ProductCategory::where('product_id',$id)->update(
               [
                   'category_id'=>$category
               ]
            );
        }
        session()->flash('success','Cập nhật thành công !');
        return redirect()->route('products.index');
    }
    // Xóa một sản phẩm
    public function delete($id)
    {
        $data=Product::find($id);
        $data->delete();
        session()->flash('success','Xóa thành công !');
        return redirect()->route('products.index');
    }

}
