<?php

namespace App\Http\Controllers\frontend;
use App\Http\Controllers\Controller;
use App\Model\Product;
use App\Models\Bill;
use App\User;
use DB;
use Auth;
class AdminBillController extends Controller
{

    // Hiện thị danh sách đơn hàng
    public function index()
    {

        if (Auth::user()->role_id==1){
            
            $bill=Bill::join('users','users.id','bill.user_info')
                ->where('bill.status',0)
                ->select('bill.*','users.name as buyer','users.email','users.phone')
                ->get();
            $admin_handling=Bill::join('users','users.id','bill.user_info')
                ->where('bill.status',1)
                ->select('bill.*','users.name as buyer','users.email','users.phone')
                ->get();
        }else{
            $user_id=Auth::user()->id;
            $bill=Bill::join('users','users.id','bill.user_info')
                ->where('user_info',$user_id)
                ->where('bill.status',0)
                ->select('bill.*','users.name as buyer','users.email','users.phone')
                ->get();
            $admin_handling=Bill::join('users','users.id','bill.user_info')
                ->where('bill.status',1)
                ->where('user_info',$user_id)
                ->select('bill.*','users.name as buyer','users.email','users.phone')
                ->get();
        }
        return view('frontend.bills.index',compact('bill','admin_handling'));

    }
    public function done()
    {

        if (Auth::user()->role_id==1){
            $bill=Bill::join('users','users.id','bill.user_info')
                ->where('bill.status',0)
                ->select('bill.*','users.name as buyer','users.email','users.phone')
                ->get();
            $admin_handling=Bill::join('users','users.id','bill.user_info')
                ->where('bill.status',1)
                ->select('bill.*','users.name as buyer','users.email','users.phone')
                ->get();
        }else{
            $user_id=Auth::user()->id;
            $bill=Bill::join('users','users.id','bill.user_info')
                ->where('user_info',$user_id)
                ->where('bill.status',0)
                ->select('bill.*','users.name as buyer','users.email','users.phone')
                ->get();
            $admin_handling=Bill::join('users','users.id','bill.user_info')
                ->where('bill.status',1)
                ->where('user_info',$user_id)
                ->select('bill.*','users.name as buyer','users.email','users.phone')
                ->get();
        }
        return view('frontend.bills.done',compact('bill','admin_handling'));

    }


    public function create()
    {
        return view('frontend.bills.create');
    }
    public function getBill($id){
        $bill=Bill::join('users','users.id','bill.user_info')
            ->select('bill.*','users.name as buyer','users.email','users.phone','users.address')
            ->find($id);
        return $bill;
    }
    public function getProductBill($product_list){
        $products=json_decode($product_list,true);
        $i=0;
        $product_list=[];
//        dd($products);
        foreach ($products as $key=>$item){
            $i++;
            $product_info=Product::find($item);
            $product_list[$i]['id']=$product_info['id'];
            $product_list[$i]['total']=$key;
            $product_list[$i]['name']=$product_info['name'];
            $product_list[$i]['avatar']=$product_info['avatar'];
            $product_list[$i]['price']=$product_info['price'];
            $product_list[$i]['price_discount']=$product_info['price_discount'];
        }
//        dd($product_list);
        return $product_list;
    }
    public function insert(UsersCreateRequest $request ){
        $name= ucwords($request->name);
        $email=$request->email;
        $pass=$request->pass;
        $phone=$request->phone;
        $address=$request->address;
        $role_id=$request->role_id;
        User::create([
            'name'=>$name,
            'email'=>$email,
            'address'=>$address,
            'phone'=>$phone,
            'password' => bcrypt($pass),
            'role_id'=>$role_id
        ]);
        session()->flash('success','Tạo thành công !');
        return redirect()->route('users.index');
    }
    public function view($id){
        $bill=$this->getBill($id);
//        dd(json_decode($bill->product_list,true));
        $product_list=[];
        if(isset($bill->product_list)){
            $product_list=$this->getProductBill($bill->product_list);
        }
//        dd($product_list);
//        if(!empty($product_list)){
//            dd($product_list);
//        }else{
//           dd(2);
//        }
        return view('frontend.bills.view',compact('bill','product_list'));
    }
    public function edit($id)
    {
        $bill=$this->getBill($id);
        $product_list=$this->getProductBill($bill->product_list);
        return view('frontend.bills.edit',compact('bill','product_list'));
    }
    public function handling($id){
        $info=Bill::find($id);
        $status=$info['status'];
        if ($status==1){
            $status_update=0;
        }else{
            $status_update=1;
        }
        $update=Bill::where('id',$id)->update(['status' => $status_update]);
        if ($update){
            session()->flash('success','Cập nhật trạng thái thành công !');
            return back();
        }
    }

}
