var ngApp = angular.module('ngApp', ['bw.paging', 'ngSanitize']);


