/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'sv', {
	confirmCleanup: 'Texten du vill klistra in verkar vara kopierad från Word. Vill du rensa den innan du klistrar in den?',
	error: 'Det var inte möjligt att städa upp den inklistrade data på grund av ett internt fel',
	title: 'Klistra in från Word',
	toolbar: 'Klistra in från Word'
} );
