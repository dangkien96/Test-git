/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'pl', {
	confirmCleanup: 'Tekst, który chcesz wkleić, prawdopodobnie pochodzi z programu Microsoft Word. Czy chcesz go wyczyścić przed wklejeniem?',
	error: 'Wyczyszczenie wklejonych danych nie było możliwe z powodu wystąpienia błędu.',
	title: 'Wklej z programu MS Word',
	toolbar: 'Wklej z programu MS Word'
} );
