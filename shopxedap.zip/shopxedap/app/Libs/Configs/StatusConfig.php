<?php

namespace App\Libs\Configs;


class StatusConfig {
	const CONST_AVAILABLE = 'AVAILABLE';
	const CONST_PENDING   = 'PENDING';
	const CONST_DRAFT     = 'DRAFT';
	const CONST_DISABLE   = 'DISABLE';
}



    
