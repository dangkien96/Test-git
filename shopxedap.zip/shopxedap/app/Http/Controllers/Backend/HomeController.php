<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Libs\Configs\StatusConfig;

use DB, App;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Product;

class HomeController extends Controller
{
	public function __construct()
	{
		$this->orderModel = new Order();
        $this->memberModel = new Customer();
        $this->productModel = new Product();
        
	}

    public function index() {
        $countOrder  = $this->orderModel->count();
        $countOrder0 = $this->orderModel->where('order_status', 0)->count();
        $countOrder1 = $this->orderModel->where('order_status', 1)->count();
        $countOrder2 = $this->orderModel->where('order_status', 2)->count();
        $countOrder3 = $this->orderModel->where('order_status', 3)->count();
        $countmember = $this->memberModel->count();
        $countProduct = $this->productModel->count();
        return view('Backend.Contents.index', array(
                                            'countOrder'  => $countOrder,
                                            'countOrder0' => $countOrder0,
                                            'countOrder1' => $countOrder1,
                                            'countOrder2' => $countOrder2, 
                                            'countOrder3' => $countOrder3,
                                            'countmember' => $countmember,
                                            'countProduct' => $countProduct,
                                            ));
    }

     public function list() {
        
        
    }

}
